###################
# Packages needed
###################

1. JMbayes
2. splines
3. survival
4. doParallel
5. MASS

#####################
# Description and usage of various files
#####################


1. The file "fittedPRIASModel.Rdata" contains a fitted joint model of the class mvJointModelBayes.
	-- It is based on the assumption that errors are normally distributed.
	-- Once you load this in R, you can call summary and plot functions on the loaded object, to view model convergence and to see parameter estimates

2. The file "dataset.Rdata" contains a sample dataset of patients on which a joint model can be fitted by following the instructions given in the file "fittingModel.R".
	-- This is not a sample of real PRIAS patients, but rather virtual patients simulated from the model that was fitted to the PRIAS dataset.
	-- Access to the PRIAS dataset is not open, and access can be obtained via https://www.prias-project.org/.

3. The files a) "expectedCondFailureTime.R", b) "replaceMCMCContentsLight.R" and c) "rocJM_mod.R" are auxiliary files that are used in the simulation study.

4. The simulation study results can be recreated using the code in the folder "simulation study".
	-- First open the folder in R and set it as the working directory. 
	-- Run the code in the "SimulateJM.R" line by line and it will conduct a simulation study and save results in the Rdata folder. It uses the following files:
		-- The auxiliary file "simCommon.R" contains code for generating simulation data sets, and fitting joint model to those datasets.
		-- The auxiliary file "nbAndOffset.R" contains code for running various personalized schedules and fixed schedules that are described in the main manuscript of our paper.
		-- The auxiliary file "rocAndCutoff.R" contains code for find optimal risk threshold "kappa" using F1 score.
